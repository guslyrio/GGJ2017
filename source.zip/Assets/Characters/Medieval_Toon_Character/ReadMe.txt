Animations taken from unity free mecanim starter tutorial package for demonstration purpose :)

Comments, suggestions, bugs, dont hesitate to contact :)

You can find more medieval toon characters here: https://www.assetstore.unity3d.com/en/#!/content/19059

Facebook page: https://www.facebook.com/nightforestgamestudio
Contact info: memelotsqui@gmail.com

Enjoy! :)
